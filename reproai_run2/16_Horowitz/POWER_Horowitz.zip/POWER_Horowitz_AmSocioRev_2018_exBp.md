Sample Size Report for Horowitz et al. (2018)
=============================================

The following is the brief description of the statistical analysis for
the focal inferential test in SCORE and the results of that test. See
the paper itself for additional background.

-   The claim is tested by regressing skill utilization (derived from
    O\*NET occupational skill ratings) on individuals’ education levels,
    relative education in their birth cohort and region net of age,
    period, cohort, and other demographic trends. The key independent
    variables are three dummy variables for educational attainment
    (completed some college, completed a four-year degree, or earned
    more education than a four-year degree, with individuals who have
    completed no college as the reference category), the proportion of
    individuals with a college degree, and the interaction of this
    variable with each of the dummy variables for education level (see
    Table 1 for the full model). For the purposes of the SCORE project,
    the effect of interest is the interaction between four-year college
    completion and the college proportion on use of verbal skills for
    men.

-   There is a significant and negative interaction term between
    education level and 4 year college completion on verbal skill
    utilization for men, coefficient = -1.648, p &lt; 0.001 (The authors
    interpret substantive significance using the effect size, see Table
    4: comparing cohorts that are 8 percent vs. 40 percent college
    educated, a hypothetical man with a college degree loses .32 points
    for verbal skill utilization, and this drop in verbal skill
    utilization is roughly the difference between a news reporter and a
    librarian). Thus, although individuals with college experience use
    verbal skills more than those without a college background do, this
    advantage declines as the proportion of college-educated individuals
    increases.

Power analysis calculation
--------------------------

For data analytic replications in SCORE, three sample sizes are
calculated:

-   A bare minimum threshold sample size,
    `rr_threshold_analytic_sample_size`, which is the sample size
    required for 50% power of 100% of the original effect
-   A stage 1 sample size, `rr_stage1_analytic_sample_size` , which is
    the sample size needed to have 90% power to detect 75% of the
    original effect
-   A stage 2 sample size, `rr_stage2_analytic_sample_size` , which is
    the sample size needed to have 90% power to detect 50% of the
    original effect

For this paper, these calculations were conducted the method shown
below:

    ### Sample size calcuations are conducted here. The source (e.g. Table 2) of each piece of information used is documented in the comments]

    orig_samp_size_units <- 'observations'

    unstand_coef <- -1.648 # from table 3
    SE <- .0555 # from table 3
    t <- unstand_coef/SE
    N <- 1003679
    n_predictors <- 1128
    Residualdf <- N - n_predictors - 1

    partial_r <-  t/sqrt(t^2 + Residualdf)
    cohenf2 <- partial_r^2/(1 - partial_r^2)

    rr_threshold_analytic_sample_size <- ceiling(pwr.f2.test(u = 1, v = NULL, f2 = cohenf2, sig.level = .05, power = .5)$v) + n_predictors + 1
    rr_stage1_analytic_sample_size <- ceiling(pwr.f2.test(u = 1, v = NULL, f2 = cohenf2 * .75, sig.level = .05, power = .9)$v) + n_predictors + 1
    rr_stage2_analytic_sample_size <- ceiling(pwr.f2.test(u = 1, v = NULL, f2 = cohenf2 * .50, sig.level = .05, power = .9)$v) + n_predictors + 1 

Sample size report
------------------

For these calculations, the primary unit of analysis are observations.
An estimate of the minimum viable sample size for the data analytic
replication is: 5497. For comparison, the stage1 required sample size
would be: 1.705910^{4} and the stage2 sample size would be:
2.502410^{4}.

Notes
-----

I can’t find any mention of clustered SE along with the FE regression,
so I’ve assumed that it’s just a FE with dummy variables and powered
accordingly, but I’ve asked the authors to varify this as the vast
majority of FE regressions we’ve come across so far also has some sort
of clusered SE (not all, but enough that I want to double check). The
exactly how many terms are in the model isn’t entirely clear. I’ve tried
to recalculate it based on their description in the note on table 3 and
the equation at the top of p.783, but that results in an extremely large
number of predictors, so I don’t have confidence in the number.

The variable of interest is an interaction that involves the proportion
of a cohort with a four-year degree, meaning there needs to be
variability in this variable (so observations can’t all come from the
same cohort). The power analysis assumes the some number of cohorts
across original and replication.

Questions for author
--------------------

What is the dfs of the test of the coefficient of interest? Can they
verify that there is no SE clustering?

    # creating reference variables

    vars <- 
    rbind(
    c(
      'pdf_filename',
      'paper_id', 
      'original_samplesize_calculation_contributor',
      'original_statistic_analysis_type',
      'original_effect_size_type_reference',
      'original_effect_size_value_reference',
      'rr_stage1_analytic_sample_size',
      'rr_stage2_analytic_sample_size', 
      'rr_threshold_analytic_sample_size', 
      'original_analytic_sample_size_value_reference',   
      'original_analytic_sample_size_units_reference', 
      'original_p_value_value_reference',
      'original_p_value_type_reference',
      'original_p_value_tails_reference',  
      'original_statistic_type_reference', 
      'original_statistic_value_reference',
      'original_statistic_df1_reference',
      'original_statistic_df2_reference',  
      'original_coefficient_type_reference',
      'original_coefficient_value_reference',
      'original_coefficient_se_reference'),
    c(
      pdf_filename,
      paper_id,
      original_samplesize_calculation_contributor,
      original_statistic_analysis_type,
      original_effect_size_type_reference <- 'cohen_f_squared',
      original_effect_size_value_reference <- cohenf2,
      rr_stage1_analytic_sample_size,
      rr_stage2_analytic_sample_size, 
      rr_threshold_analytic_sample_size,
      original_analytic_sample_size_value_reference <- N,   
      original_analytic_sample_size_units_reference <- orig_samp_size_units, 
      original_p_value_value_reference <- NA,
      original_p_value_type_reference <- NA,
      original_p_value_tails_reference <- NA,  
      original_statistic_type_reference <- 't-test', 
      original_statistic_value_reference <- t,
      original_statistic_df1_reference <- NA,
      original_statistic_df2_reference <- Residualdf,  
      original_coefficient_type_reference <- 'FE regression coefficient',
      original_coefficient_value_reference <- unstand_coef,
      original_coefficient_se_reference <- SE))

    # output coded reference variables as tsv file, to be uploaded with .md and .Rmd files
    as_tibble(vars) %>% 
      row_to_names(1) %>%
      write_tsv(paste0(pdf_filename, '_power_vars.tsv'))

    ## Warning: The `x` argument of `as_tibble.matrix()` must have unique column names if `.name_repair` is omitted as of tibble 2.0.0.
    ## Using compatibility `.name_repair`.
    ## This warning is displayed once every 8 hours.
    ## Call `lifecycle::last_warnings()` to see where this warning was generated.

    # show non-null variables at end of power report
    as_tibble(vars) %>% 
      row_to_names(1) %>% 
      pivot_longer(pdf_filename:original_coefficient_se_reference, names_to = 'variable', values_to = 'value') %>% 
      filter(!is.na(value))

    ## # A tibble: 17 x 2
    ##    variable                                      value                        
    ##    <chr>                                         <chr>                        
    ##  1 pdf_filename                                  Horowitz_AmSocioRev_2018_exBp
    ##  2 paper_id                                      exBp                         
    ##  3 original_samplesize_calculation_contributor   Courtney Soderberg           
    ##  4 original_statistic_analysis_type              FE regression                
    ##  5 original_effect_size_type_reference           cohen_f_squared              
    ##  6 original_effect_size_value_reference          0.000879472789561523         
    ##  7 rr_stage1_analytic_sample_size                17059                        
    ##  8 rr_stage2_analytic_sample_size                25024                        
    ##  9 rr_threshold_analytic_sample_size             5497                         
    ## 10 original_analytic_sample_size_value_reference 1003679                      
    ## 11 original_analytic_sample_size_units_reference observations                 
    ## 12 original_statistic_type_reference             t-test                       
    ## 13 original_statistic_value_reference            -29.6936936936937            
    ## 14 original_statistic_df2_reference              1002550                      
    ## 15 original_coefficient_type_reference           FE regression coefficient    
    ## 16 original_coefficient_value_reference          -1.648                       
    ## 17 original_coefficient_se_reference             0.0555
